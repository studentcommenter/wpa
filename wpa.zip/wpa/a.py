import numpy as np
import matplotlib.pyplot as plt
from matplotlib.animation import FuncAnimation
from mpl_toolkits.mplot3d import Axes3D
from matplotlib.widgets import Slider, Button
import random
import math

class ConfigurableWolfPack3D:
    def __init__(self, num_wolves=5, bounds=(-5, 5), max_iterations=50):
        self.num_wolves = num_wolves
        self.bounds = bounds
        self.max_iterations = max_iterations
        
        # Default parameters
        self.initial_scout_step = 0.6
        self.initial_ferocious_step = 1.0
        self.scout_step = 0.6
        self.ferocious_step = 1.0
        self.step_decay = 0.95
        self.detection_radius = 3.0
        
        # Wolf distribution
        self.num_scouts = 2
        self.num_ferocious = 2
        self.num_leader = 1
        
        # Animation control variables
        self.is_running = False
        self.anim = None
        self.fig = None
        
        # Initialize algorithm
        self.reset_algorithm()
        
    def set_max_iterations(self, new_max):
        """Update max iterations dynamically"""
        self.max_iterations = int(new_max)
        print(f"Max iterations updated to: {self.max_iterations}")
        
    def reset_algorithm(self):
        """Reset the algorithm to initial state"""
        self.wolves = self.initialize_population()
        self.best_history = []
        self.iteration = 0
        self.is_running = False
        self.scout_step = self.initial_scout_step
        self.ferocious_step = self.initial_ferocious_step
        
        # Reset animation if it exists
        if self.anim is not None:
            self.anim.event_source.stop()
            self.anim = None
        
    def objective_function(self, x, y):
        """Objective function: f(x,y) = x^2 + y^2"""
        return x**2 + y**2
    
    def setup_3d_plot(self):
        """Setup 3D surface plot with proper figure management"""
        # Close any existing figure to prevent conflicts
        if self.fig is not None:
            plt.close(self.fig)
            
        self.fig = plt.figure(figsize=(18, 10))
        
        # Main 3D plot
        self.ax3d = self.fig.add_subplot(121, projection='3d')
        
        # Convergence plot
        self.ax_conv = self.fig.add_subplot(122)
        
        # Create surface mesh
        x_vals = np.linspace(self.bounds[0], self.bounds[1], 50)
        y_vals = np.linspace(self.bounds[0], self.bounds[1], 50)
        self.X, self.Y = np.meshgrid(x_vals, y_vals)
        self.Z = self.objective_function(self.X, self.Y)
        
        # Setup parameter sliders
        self.setup_sliders()
        
    def setup_sliders(self):
        """Create interactive parameter sliders including iterations"""
        slider_height = 0.025
        slider_width = 0.22
        left_margin = 0.08
        bottom_start = 0.02
        
        # Create slider axes
        ax_scout = plt.axes([left_margin, bottom_start, slider_width, slider_height])
        ax_ferocious = plt.axes([left_margin, bottom_start + 0.04, slider_width, slider_height])
        ax_decay = plt.axes([left_margin, bottom_start + 0.08, slider_width, slider_height])
        ax_detect = plt.axes([left_margin, bottom_start + 0.12, slider_width, slider_height])
        ax_iterations = plt.axes([left_margin, bottom_start + 0.16, slider_width, slider_height])
        
        # Create sliders
        self.slider_scout = Slider(ax_scout, 'Scout Step', 0.1, 2.0, 
                                  valinit=self.initial_scout_step, valfmt='%.2f')
        self.slider_ferocious = Slider(ax_ferocious, 'Ferocious Step', 0.1, 2.0, 
                                      valinit=self.initial_ferocious_step, valfmt='%.2f')
        self.slider_decay = Slider(ax_decay, 'Step Decay', 0.80, 0.99, 
                                  valinit=self.step_decay, valfmt='%.3f')
        self.slider_detect = Slider(ax_detect, 'Detection Radius', 1.0, 8.0, 
                                   valinit=self.detection_radius, valfmt='%.1f')
        self.slider_iterations = Slider(ax_iterations, 'Max Iterations', 10, 200, 
                                       valinit=self.max_iterations, valfmt='%d')
        
        # Connect sliders
        self.slider_scout.on_changed(self.update_parameters)
        self.slider_ferocious.on_changed(self.update_parameters)
        self.slider_decay.on_changed(self.update_parameters)
        self.slider_detect.on_changed(self.update_parameters)
        self.slider_iterations.on_changed(self.update_iterations)
        
        # Add control buttons
        ax_start = plt.axes([0.35, 0.02, 0.06, 0.04])
        ax_reset = plt.axes([0.42, 0.02, 0.06, 0.04])
        ax_pause = plt.axes([0.49, 0.02, 0.06, 0.04])
        ax_restart = plt.axes([0.56, 0.02, 0.06, 0.04])
        
        self.btn_start = Button(ax_start, 'Start')
        self.btn_reset = Button(ax_reset, 'Reset')
        self.btn_pause = Button(ax_pause, 'Pause')
        self.btn_restart = Button(ax_restart, 'Restart')
        
        self.btn_start.on_clicked(self.start_animation)
        self.btn_reset.on_clicked(self.reset_simulation)
        self.btn_pause.on_clicked(self.pause_animation)
        self.btn_restart.on_clicked(self.restart_animation)
        
    def update_parameters(self, val):
        """Update algorithm parameters from sliders"""
        self.initial_scout_step = self.slider_scout.val
        self.initial_ferocious_step = self.slider_ferocious.val
        self.step_decay = self.slider_decay.val
        self.detection_radius = self.slider_detect.val
        
    def update_iterations(self, val):
        """Update max iterations from slider"""
        self.set_max_iterations(self.slider_iterations.val)
        
    def initialize_population(self):
        """Initialize wolf population"""
        wolves = []
        for i in range(self.num_wolves):
            x = random.uniform(self.bounds[0], self.bounds[1])
            y = random.uniform(self.bounds[0], self.bounds[1])
            fitness = self.objective_function(x, y)
            
            if i == 0:
                wolf_type = 'leader'
            elif i <= self.num_scouts:
                wolf_type = 'scout'
            else:
                wolf_type = 'ferocious'
                
            wolves.append({
                'id': i,
                'type': wolf_type,
                'position': [x, y],
                'fitness': fitness,
                'trail': [[x, y]],
                'called_count': 0
            })
        
        self.update_leader(wolves)
        return wolves
    
    def update_leader(self, wolves):
        """Update leader based on winner-take-all rule"""
        best_wolf = min(wolves, key=lambda w: w['fitness'])
        
        for wolf in wolves:
            if wolf['id'] == best_wolf['id']:
                wolf['type'] = 'leader'
            elif wolf['type'] == 'leader':
                wolf['type'] = 'ferocious'
    
    def scout_movement(self, wolf):
        """Scout wolf exploration movement"""
        theta = random.uniform(0, 2 * math.pi)
        delta_x = self.scout_step * math.cos(theta)
        delta_y = self.scout_step * math.sin(theta)
        
        new_x = wolf['position'][0] + delta_x
        new_y = wolf['position'][1] + delta_y
        
        # Apply boundary constraints
        new_x = max(self.bounds[0], min(self.bounds[1], new_x))
        new_y = max(self.bounds[0], min(self.bounds[1], new_y))
        
        new_fitness = self.objective_function(new_x, new_y)
        
        wolf['position'] = [new_x, new_y]
        wolf['fitness'] = new_fitness
        wolf['trail'].append([new_x, new_y])
        
        # Keep trail length manageable
        if len(wolf['trail']) > 25:
            wolf['trail'] = wolf['trail'][-25:]
            
        return wolf
    
    def calculate_distance(self, pos1, pos2):
        """Calculate Euclidean distance"""
        return math.sqrt((pos1[0] - pos2[0])**2 + (pos1[1] - pos2[1])**2)
    
    def calling_behavior(self, leader, ferocious_wolves):
        """Leader calls nearby ferocious wolves"""
        called_wolves = []
        
        for wolf in ferocious_wolves:
            distance = self.calculate_distance(leader['position'], wolf['position'])
            if distance <= self.detection_radius:
                called_wolves.append(wolf)
                wolf['called_count'] += 1
        
        return called_wolves
    
    def besieging_movement(self, wolf, leader):
        """Ferocious wolf moves toward leader"""
        dx = leader['position'][0] - wolf['position'][0]
        dy = leader['position'][1] - wolf['position'][1]
        
        distance = math.sqrt(dx**2 + dy**2)
        
        if distance > 0:
            unit_dx = dx / distance
            unit_dy = dy / distance
            
            move_x = self.ferocious_step * unit_dx
            move_y = self.ferocious_step * unit_dy
            
            new_x = wolf['position'][0] + move_x
            new_y = wolf['position'][1] + move_y
            
            # Apply boundary constraints
            new_x = max(self.bounds[0], min(self.bounds[1], new_x))
            new_y = max(self.bounds[0], min(self.bounds[1], new_y))
            
            new_fitness = self.objective_function(new_x, new_y)
            
            wolf['position'] = [new_x, new_y]
            wolf['fitness'] = new_fitness
            wolf['trail'].append([new_x, new_y])
            
            if len(wolf['trail']) > 25:
                wolf['trail'] = wolf['trail'][-25:]
        
        return wolf
    
    def run_iteration(self):
        """Execute one iteration of the algorithm"""
        if self.iteration >= self.max_iterations:
            self.is_running = False
            return
            
        leader = next(wolf for wolf in self.wolves if wolf['type'] == 'leader')
        scouts = [wolf for wolf in self.wolves if wolf['type'] == 'scout']
        ferocious = [wolf for wolf in self.wolves if wolf['type'] == 'ferocious']
        
        leadership_changed = False
        
        # Scouting phase
        for scout in scouts:
            scout = self.scout_movement(scout)
            if scout['fitness'] < leader['fitness']:
                leadership_changed = True
                leader = scout
        
        if leadership_changed:
            self.update_leader(self.wolves)
            leader = next(wolf for wolf in self.wolves if wolf['type'] == 'leader')
        
        # Calling and besieging phase
        called_wolves = self.calling_behavior(leader, ferocious)
        
        for wolf in called_wolves:
            wolf = self.besieging_movement(wolf, leader)
            if wolf['fitness'] < leader['fitness']:
                self.update_leader(self.wolves)
                leader = next(wolf for wolf in self.wolves if wolf['type'] == 'leader')
        
        # Update parameters with decay
        self.scout_step *= self.step_decay
        self.ferocious_step *= self.step_decay
        self.iteration += 1
        self.best_history.append(leader['fitness'])
    
    def update_3d_plot(self, frame):
        """Update 3D visualization"""
        if self.is_running and self.iteration < self.max_iterations:
            self.run_iteration()
        elif self.iteration >= self.max_iterations:
            self.is_running = False
        
        # Clear plots
        self.ax3d.clear()
        self.ax_conv.clear()
        
        # Plot surface
        surf = self.ax3d.plot_surface(self.X, self.Y, self.Z, cmap='viridis', 
                                     alpha=0.6, edgecolor='none')
        
        # Plot contour lines
        self.ax3d.contour(self.X, self.Y, self.Z, levels=15, colors='black', 
                         alpha=0.3, linewidths=0.5)
        
        # Wolf visualization
        colors = {'leader': 'red', 'scout': 'blue', 'ferocious': 'green'}
        sizes = {'leader': 200, 'scout': 100, 'ferocious': 120}
        markers = {'leader': '*', 'scout': 'o', 'ferocious': 's'}
        
        # Plot wolf trails
        for wolf in self.wolves:
            if len(wolf['trail']) > 1:
                trail = np.array(wolf['trail'])
                z_trail = [self.objective_function(pos[0], pos[1]) for pos in trail]
                self.ax3d.plot(trail[:, 0], trail[:, 1], z_trail, 
                              color=colors[wolf['type']], alpha=0.6, linewidth=3)
        
        # Plot current positions
        for wolf in self.wolves:
            x, y = wolf['position']
            z = self.objective_function(x, y)
            self.ax3d.scatter(x, y, z, c=colors[wolf['type']], 
                             s=sizes[wolf['type']], marker=markers[wolf['type']], 
                             edgecolors='black', linewidth=2)
        
        # Mark global optimum
        self.ax3d.scatter(0, 0, 0, c='yellow', s=300, marker='X', 
                         edgecolors='black', linewidth=3)
        
        # Detection radius
        leader = next(wolf for wolf in self.wolves if wolf['type'] == 'leader')
        theta_circle = np.linspace(0, 2*np.pi, 50)
        x_circle = leader['position'][0] + self.detection_radius * np.cos(theta_circle)
        y_circle = leader['position'][1] + self.detection_radius * np.sin(theta_circle)
        z_circle = [self.objective_function(x, y) for x, y in zip(x_circle, y_circle)]
        self.ax3d.plot(x_circle, y_circle, z_circle, 'r--', alpha=0.7, linewidth=3)
        
        # Set plot properties
        self.ax3d.set_xlim(self.bounds[0], self.bounds[1])
        self.ax3d.set_ylim(self.bounds[0], self.bounds[1])
        self.ax3d.set_zlim(0, np.max(self.Z))
        self.ax3d.set_xlabel('X', fontsize=12)
        self.ax3d.set_ylabel('Y', fontsize=12)
        self.ax3d.set_zlabel('f(x,y) = x² + y²', fontsize=12)
        
        current_best = min(wolf['fitness'] for wolf in self.wolves)
        progress = (self.iteration / self.max_iterations) * 100
        
        self.ax3d.set_title(f'Configurable Wolf Pack Algorithm\n'
                           f'Iteration {self.iteration}/{self.max_iterations} ({progress:.1f}%)\n'
                           f'Best Fitness: {current_best:.6f}', fontsize=10)
        
        # Convergence plot
        if self.best_history:
            self.ax_conv.plot(range(1, len(self.best_history) + 1), 
                             self.best_history, 'b-', linewidth=2, marker='o', markersize=4)
            self.ax_conv.set_xlabel('Iteration')
            self.ax_conv.set_ylabel('Best Fitness (log scale)')
            self.ax_conv.set_title('Convergence History')
            self.ax_conv.set_yscale('log')
            self.ax_conv.grid(True, alpha=0.3)
            
            # Statistics
            if len(self.best_history) > 1:
                improvement = ((self.best_history[0] - self.best_history[-1]) / 
                             self.best_history[0] * 100)
                distance_to_optimum = math.sqrt(leader['position'][0]**2 + leader['position'][1]**2)
                
                stats_text = (f'Max Iterations: {self.max_iterations}\n'
                            f'Current: {self.iteration}\n'
                            f'Initial: {self.best_history[0]:.4f}\n'
                            f'Best: {self.best_history[-1]:.6f}\n'
                            f'Improvement: {improvement:.1f}%\n'
                            f'Distance to (0,0): {distance_to_optimum:.3f}')
                
                self.ax_conv.text(0.02, 0.98, stats_text,
                                transform=self.ax_conv.transAxes, 
                                verticalalignment='top',
                                bbox=dict(boxstyle='round', facecolor='lightgreen', alpha=0.8))
        
        plt.tight_layout()
    
    def start_animation(self, event=None):
        """Start the animation with proper error handling"""
        try:
            self.is_running = True
            if self.anim is None:
                self.anim = FuncAnimation(self.fig, self.update_3d_plot, 
                                        frames=self.max_iterations, 
                                        interval=600, repeat=False, blit=False)
            print(f"Animation started with {self.max_iterations} max iterations")
        except Exception as e:
            print(f"Error starting animation: {e}")
            self.is_running = False
    
    def pause_animation(self, event=None):
        """Pause/resume the animation"""
        self.is_running = not self.is_running
        status = "resumed" if self.is_running else "paused"
        print(f"Animation {status}")
    
    def reset_simulation(self, event=None):
        """Reset the simulation"""
        self.is_running = False
        self.reset_algorithm()
        print("Simulation reset")
        
    def restart_animation(self, event=None):
        """Restart animation from beginning"""
        self.is_running = False
        if self.anim is not None:
            self.anim.event_source.stop()
            self.anim = None
        self.reset_algorithm()
        self.start_animation()
        print("Animation restarted")
    
    def show(self):
        """Display the interactive visualization with proper setup"""
        try:
            # Setup the plot
            self.setup_3d_plot()
            
            print("=== Configurable 3D Wolf Pack Algorithm ===")
            print("NEW FEATURES:")
            print("✓ Configurable max iterations (10-200)")
            print("✓ Fixed animation running issues")
            print("✓ Restart button for fresh runs")
            print("✓ Progress tracking")
            print("\nControls:")
            print("- Adjust sliders to change parameters")
            print("- Start: Begin animation")
            print("- Pause: Pause/resume")
            print("- Reset: Reset current run")
            print("- Restart: Fresh start with new parameters")
            
            # Initial plot
            self.update_3d_plot(0)
            
            # Show the plot
            plt.show()
            
        except Exception as e:
            print(f"Error displaying visualization: {e}")
            print("Try closing any existing matplotlib windows and run again")

# Create and run the configurable visualization
if __name__ == "__main__":
    # Create with configurable iterations
    wpa3d = ConfigurableWolfPack3D(num_wolves=5, bounds=(-5, 5), max_iterations=75)
    
    # Demonstrate iteration configuration
    print(f"Initial max iterations: {wpa3d.max_iterations}")
    wpa3d.set_max_iterations(100)
    print(f"Updated max iterations: {wpa3d.max_iterations}")
    
    # Show the visualization
    wpa3d.show()

